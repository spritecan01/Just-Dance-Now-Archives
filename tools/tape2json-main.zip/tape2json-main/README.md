<h1 align="center">tape2json</h1>
<h3 align="center"> - Tool for converting Just Dance tapes to Just Dance Now json's - </h3>

## How to use tape2json:
 - Download node and npm.
 - Open cmd and paste "npm i"
 - Paste ".dtape.ckd" to "dtape-input.json", ".ktape.ckd" to "ktape-input.json", "_musictrack.tpl.ckd" to "musictrack-input.json", "songdesc.tpl.ckd" to "songdesc-input.json" inside input directory
 - Run start.bat
 - Tapes successfully converted to json 🥳
 
## Answers to some questions:
- How to make output a jsonp? Open setting.json change parameter (jsonp) value from false to true.
- How to change output folder? Open setting.json change parameter (outputFolder) value to on what you want.
- How to change input folder? Open setting.json change parameter (inputFolder) value to on what you want.

<h4>Credit Bezdrom in your work 😘</h4>
